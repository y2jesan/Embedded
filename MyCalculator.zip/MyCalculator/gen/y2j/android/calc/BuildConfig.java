/** Automatically generated file. DO NOT MODIFY */
package y2j.android.calc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}