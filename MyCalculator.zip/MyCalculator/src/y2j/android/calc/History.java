package y2j.android.calc;



public class History {
	int id;
	String first;
	String second;
	String sign;
	String result;
	String datetime;
	
	public History( String fst, String sec, String sig,String res, String dt)
	{
		//this.id=id;
		this.first=fst;
		this.second=sec;
		this.sign=sig;
		this.result=res;
		this.datetime=dt.toString();
	}
	public History(){
		
	}
	
	public int getId(){
		return this.id;
	}
	public void setId(int i){
		this.id=i;
	}
	
	public String getFirst(){
		return this.first;
	}
	public void setFirst(String f){
		this.first=f;
	}
	
	public String getSecond(){
		return this.second;
	}
	public void setSecond(String s){
		this.second=s;
	}
	
	public String getSign(){
		return this.sign;
	}
	public void setSign(String s){
		this.sign=s;
	}
	public String getResult(){
		return this.result;
	}
	public void setResult(String r){
		this.result=r;
	}
	public String getDatetime(){
		return this.datetime;
	}
	public void setDatetime(String dt){
		this.datetime=dt.toString();
	}
	
	
	
}
