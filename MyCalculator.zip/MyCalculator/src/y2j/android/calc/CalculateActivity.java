package y2j.android.calc;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;



public class CalculateActivity extends Activity {
	
	Date CalcDate;
	FileOutputStream fos;
	String FILENAME = "logfile.txt";
	
	
	public void writeLog(String v1,String v2,String sign, double res)
	{
		
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Calendar cal=Calendar.getInstance();
		String CurrentDateTime =  dateFormat.format(cal.getTime());
		
		String LogData = ""+CurrentDateTime+" : "+ v1 +" "+sign+" "+v2+" = " +res+"\n";
		
		try{
			fos = openFileOutput(FILENAME, Context.MODE_APPEND);
			fos.write(LogData.getBytes());
			fos.close();
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		
	}
	
	public void addSQL(String v1,String v2,String sign, double res){
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Calendar cal=Calendar.getInstance();
		String CurrentDateTime =  dateFormat.format(cal.getTime());
		String R = Double.toString(res);
		
		DbHandler db = new DbHandler(this);
		
		db.addHistory(new History(v1,v2,sign,R , CurrentDateTime.toString()));
		//Log.d("txt","hoise");
		List<History> histories = db.getAllHistories();       
		 
        for (History his : histories) {
            String log = "Calculation: "+ his.getFirst() +" "+ his.getSign()+" "+ his.getSecond()+" = "+ his.getResult() + " Time :"+ his.getDatetime();
                
        Log.d("Name: ", log );
        }
		
	}
	
	
	public void calculate(Intent i, String sign, String fst, String snd){
		if(sign.equals("+")){
	    	double varResult = ((Double.parseDouble(fst)) + (Double.parseDouble(snd)));
			
	    	i.putExtra("varResult", String.valueOf(varResult));
			setResult(Activity.RESULT_OK, i);
			
			writeLog(fst,snd,sign,varResult);
			addSQL(fst,snd,sign,varResult);
			
			finish();
		}
		else if(sign.equals("-")){
	    	double varResult = ((Double.parseDouble(fst)) - (Double.parseDouble(snd)));
			
	    	i.putExtra("varResult", String.valueOf(varResult));
			setResult(Activity.RESULT_OK, i);
			
			writeLog(fst,snd,sign,varResult);
			addSQL(fst,snd,sign,varResult);
			finish();
		}
		else if(sign.equals("*")){
	    	double varResult = ((Double.parseDouble(fst)) * (Double.parseDouble(snd)));
			
	    	i.putExtra("varResult", String.valueOf(varResult));
			setResult(Activity.RESULT_OK, i);
			writeLog(fst,snd,sign,varResult);
			addSQL(fst,snd,sign,varResult);
			finish();
		}
		else if(sign.equals("/")){
	    	double varResult = ((Double.parseDouble(fst)) / (Double.parseDouble(snd)));
			
	    	i.putExtra("varResult", String.valueOf(varResult));
			setResult(Activity.RESULT_OK, i);
			writeLog(fst,snd,sign,varResult);
			addSQL(fst,snd,sign,varResult);
			finish();
		}
		
	}
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        
        
        Intent Result = new Intent();
        Result = getIntent();
        
        if(Result != null){
            String first = Result.getStringExtra("first");
            String second = Result.getStringExtra("second");
            String sign = Result.getStringExtra("sign");
            
            calculate(Result, sign, first, second);
        }
        else{
        	setResult(Activity.RESULT_CANCELED, Result);
			finish();
        }
     
    }

}
