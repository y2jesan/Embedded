package y2j.android.calc;



import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MyCalculatorActivity extends Activity {
    /** Called when the activity is first created. */
	private EditText inputText;
	private EditText resultText;
	
	private Button button0; 
	private Button button1; 
	private Button button2; 
	private Button button3; 
	private Button button4; 
	private Button button5;
	private Button button6; 
	private Button button7; 
	private Button button8; 
	private Button button9; 
	private Button buttonAdd; 
	private Button buttonSub;
	private Button buttonMul; 
	private Button buttonDiv; 
	private Button buttonMR; 
	private Button buttonMS; 
	private Button buttonMp; 
	private Button buttonMm;
	private Button buttonMC;
	private Button buttonC; 
	private Button buttonCE; 
	private Button buttonSqr; 
	private Button buttonEql; 
	private Button button00; 
	private Button historyBtn;
	
	String displayString = "";
	
	private String first; 
    private String second; 
    private String sign;
    private String memory;
    public static final String PREFERENCES_NAME = "MyCalculatorPreferences";
	
    public void numberClick(Button btnValue){
		if(this.sign == ""){
			if(this.inputText.length() < 15){
				displayString += "" + btnValue.getText().toString();
				this.inputText.setText(displayString);
				
				this.sign = "";
				
				this.first = displayString.toString();
			}else{
				Toast.makeText(this, "Too Long", Toast.LENGTH_LONG).show();
			
			}	
		}else{
    		displayString += "" + btnValue.getText().toString();
			this.inputText.setText(displayString);
		}
    }
    
    public void memoryButtonProcess(Button btnLogic){
    	if(btnLogic.getText().equals("M+")){
    		add(this.inputText.getText().toString());
    		displayString = "";
    		this.inputText.setText(displayString);
    	}
		if(btnLogic.getText().equals("M-")){
		    sub(this.inputText.getText().toString());	
		    displayString = "";
    		this.inputText.setText(displayString);
		}
		if(btnLogic.getText().equals("MR")){
			show();
		}
		if(btnLogic.getText().equals("MS")){
    		store(this.inputText.getText().toString());
    	}
		if(btnLogic.getText().equals("MC")){
			clear();
		}
    }
    
    public void add(String newValue){
    	SharedPreferences sharedPref = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = sharedPref.edit();
    	
    		double oldValue = Double.parseDouble(sharedPref.getString("result", "0"));
    		editor.putString("result", String.valueOf(Double.parseDouble(newValue) + oldValue));
    		editor.commit();
    		
    		Toast.makeText(this, "Added in the Memory !", Toast.LENGTH_LONG).show();

    }
    
    public void sub(String newValue){
    	SharedPreferences sharedPref = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = sharedPref.edit();

    		double oldValue = Double.parseDouble(sharedPref.getString("result", "0"));
    		editor.putString("result", String.valueOf(Double.parseDouble(newValue) - oldValue));
    		editor.commit();
    		
    		Toast.makeText(this, "Subtracted in the Memory !", Toast.LENGTH_LONG).show();

    }
    
    public void show(){
    	SharedPreferences sharedPref = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    	
    	displayString = sharedPref.getString("result", this.memory.toString());
    	
    	this.resultText.setText("" + displayString);
    }
    public void store(String S){
    	SharedPreferences sharedPref = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = sharedPref.edit();
    	
    	
    		
    		editor.putString("result", S);
        	editor.commit();
    	
    	
    	Toast.makeText(this, "Saved", Toast.LENGTH_LONG).show();
    }
    public void clear(){
    	SharedPreferences sharedPref = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = sharedPref.edit();
    	
    	editor.putString("result","0");
    	editor.commit();
    	
    	Toast.makeText(this, "Memory Cleared !", Toast.LENGTH_LONG).show();
    	
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        //Intent m = new Intent();
        //m = getIntent();
        
        this.sign = "";
        this.first = "";
        this.memory = "";
        
        this.inputText = (EditText)findViewById(R.id.inputText);
        this.inputText.setText("0");
        
        this.resultText = (EditText)findViewById(R.id.resultText);
        this.resultText.setText("0");
        
        this.button0 = (Button)findViewById(R.id.button0);
        this.button1 = (Button)findViewById(R.id.button1);
        this.button2 = (Button)findViewById(R.id.button2);
        this.button3 = (Button)findViewById(R.id.button3);
        this.button4 = (Button)findViewById(R.id.button4);
        this.button5 = (Button)findViewById(R.id.button5);
        this.button6 = (Button)findViewById(R.id.button6);
        this.button7 = (Button)findViewById(R.id.button7);
        this.button8 = (Button)findViewById(R.id.button8);
        this.button9 = (Button)findViewById(R.id.button9);
        this.button00 = (Button)findViewById(R.id.button00);
        this.buttonAdd = (Button)findViewById(R.id.buttonAdd);
        this.buttonSub = (Button)findViewById(R.id.buttonSub);
        this.buttonMul = (Button)findViewById(R.id.buttonMul);
        this.buttonDiv = (Button)findViewById(R.id.buttonDiv);
        this.buttonEql = (Button)findViewById(R.id.buttonEql);
        this.buttonC = (Button)findViewById(R.id.buttonC);
        this.buttonCE = (Button)findViewById(R.id.buttonCE);
        this.buttonMS = (Button)findViewById(R.id.buttonMS);
        this.buttonMR = (Button)findViewById(R.id.buttonMR);
        this.buttonMp = (Button)findViewById(R.id.buttonMp);
        this.buttonMm = (Button)findViewById(R.id.buttonMm);
        this.buttonMC = (Button)findViewById(R.id.buttonMC);
        this.buttonSqr = (Button)findViewById(R.id.buttonSqr);
        this.historyBtn = (Button)findViewById(R.id.historyBtn);
        
        //db
        
        //DatabaseHandler db = new DatabaseHandler(); 
        
        //button Click
        
        button0.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button0);
        	}
        });
        button1.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button1);
        	}
        });
        button2.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button2);
        	}
        });
        button3.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button3);
        	}
        });
        button4.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button4);
        	}
        });
        button5.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button5);
        	}
        });
        button6.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button6);
        	}
        });
        button7.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button7);
        	}
        });
        button8.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button8);
        	}
        });
        button9.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button9);
        	}
        });
        button00.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		numberClick(button00);
        	}
        	
        });
        
        buttonC.setOnClickListener(new OnClickListener(){
        	
        	public void onClick(View view){
        		if(displayString != null || displayString != ""){
        			displayString = new StringBuilder(inputText.getText()).deleteCharAt(displayString.length() - 1).toString();
        			inputText.setText("" + displayString);
        		}else{
        			inputText.setText("");
        		}
        	}
        });
        
        buttonCE.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		displayString = "";
        		inputText.setText("");
        		resultText.setText("");
        	}
        });
        
        buttonAdd.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		sign = "+";
        		displayString = "";
        		inputText.setText("");
        	}
        });
        buttonSub.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		sign = "-";
        		displayString = "";
        		inputText.setText("");
        	}
        });
        buttonMul.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		sign = "*";
        		displayString = "";
        		inputText.setText("");
        	}
        });
        buttonDiv.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		sign = "/";
        		displayString = "";
        		inputText.setText("");
        	}
        });
        
        buttonSqr.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		first = displayString.toString();
        		second = displayString.toString();
    			sign = "*";
    			Intent i = new Intent(MyCalculatorActivity.this, CalculateActivity.class);
    			i.putExtra("first", first);
    			i.putExtra("second", second);
    			i.putExtra("sign", sign);
    			
    			startActivityForResult(i, 1);
        	}
        });
        
        buttonEql.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){	
    			second = displayString.toString();
    			
    			Intent i = new Intent(MyCalculatorActivity.this, CalculateActivity.class);
    			i.putExtra("first", first);
    			i.putExtra("second", second);
    			i.putExtra("sign", sign);
    			
    			startActivityForResult(i, 1);
        	}
        });
        historyBtn.setOnClickListener(new OnClickListener (){
        	public void onClick(View view){	
    			Intent i = new Intent(getApplicationContext(), HistoryActivity.class);
    			startActivity(i);
        	}
        });

        //memory
        buttonMS.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		memoryButtonProcess(buttonMS);
        	}
        });
        buttonMR.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		memoryButtonProcess(buttonMR);
        	}
        });
        buttonMp.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		memoryButtonProcess(buttonMp);
        	}
        });
        buttonMm.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		memoryButtonProcess(buttonMm);
        	}
        });
        buttonMC.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        		memoryButtonProcess(buttonMC);
        	}
        });
        
        
        
        
        
        
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data){
    	super.onActivityResult(requestCode, resultCode, data);
    	
    	if(requestCode == 1 && resultCode == RESULT_OK){   		
    		displayString = data.getStringExtra("varResult".toString());
    		
    		//this.memory = first;
    		this.inputText.setText("" + first + sign + second );
			this.resultText.setText("" + displayString);
			first = data.getStringExtra("varResult");
			sign = "";
			displayString = "";
			
    	}else{
    		this.resultText.setText("" + "Something's went wrong, please try again !");
    	}
    }
    public void onConfugurationChanged(Configuration newConfig){
    	super.onConfigurationChanged(newConfig);
    	if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
    		setContentView(R.layout.main);
    	}
    	else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE){
    		setContentView(R.layout.main);
    	}
    }
    
}