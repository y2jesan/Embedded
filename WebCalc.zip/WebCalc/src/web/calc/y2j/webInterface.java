package web.calc.y2j;

import android.content.Context;
import android.widget.Toast;

public class webInterface {
	Context Con;
	String Op = "";
	String Fnum = "";
	String Snum = "";
	String x="";
	Double y=0.0;
	public webInterface(Context con){
		this.Con=con;
	}
	public void addNum(String n) 
	{
       Snum+=""+n;
    }
    public void addOperator(String opr) {
    	if(Op==""){
    		Op=opr;
        	Fnum=Snum;
        	Snum="";
    	}
    	else
    	{
    		Toast.makeText(this.Con, "Error", Toast.LENGTH_LONG).show();
    	} 	
    }
    public double getResult() {
        //window.alert("test res");
    	x=Snum;
    	if(Op.equals("+")){
    		Snum="";
    		Op="";
    		y=(Double.parseDouble(Fnum)) + (Double.parseDouble(x));
    		Fnum=String.valueOf(y);
			return (y);
		}else if(Op.equals("-")){
			Snum="";
			Op="";
			return ((Double.parseDouble(Fnum)) - (Double.parseDouble(x)));
		}else if(Op.equals("*")){
			Snum="";
			Op="";
			return ((Double.parseDouble(Fnum)) * (Double.parseDouble(x)));
		}else if(Op.equals("/")){
			Snum="";
			Op="";
			return ((Double.parseDouble(Fnum)) / (Double.parseDouble(x)));
		}else{
			Op="";
			return 0.00;
		}
    }

}
