package web.calc.y2j;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class HistoryActivity extends Activity{
	String HistoryString = "";
	private TextView historyLabel;
	private Button backBtn;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history);
        
        historyLabel = (TextView)findViewById(R.id.historyLabel);
        backBtn = (Button)findViewById(R.id.backBtn);
        
        historyLabel.setText(HistoryString);
        DbHandler db = new DbHandler(this);
        List<History> histories = db.getAllHistories();       
		 
        for (History his : histories) {
            HistoryString = "\nCalc: "+ his.getFirst() +" "+ his.getSign()+" "+ his.getSecond()+" = "+ his.getResult() + " Time :"+ his.getDatetime();
            historyLabel.append(HistoryString);
        }
        
        backBtn.setOnClickListener(new OnClickListener (){
        	public void onClick(View view){	
    			//Intent i = new Intent(HistoryActivity.this, MyCalculatorActivity.class);
    			//startActivity(i);
        		Intent His = getIntent();
        		setResult(Activity.RESULT_OK, His);
        		finish();
        	}
        });
        
	}
	

}
