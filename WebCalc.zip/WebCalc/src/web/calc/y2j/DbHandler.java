package web.calc.y2j;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHandler extends SQLiteOpenHelper{
	private static final int DATABASE_VERSION = 1;
	private static final String DATABASE_NAME = "calcHistory";
	private static final String TABLE_HISTORYS = "history";
	
	private static final String KEY_ID = "id";
	private static final String KEY_FIRST = "first";
	private static final String KEY_SECOND = "second";
	private static final String KEY_SIGN = "sign";
	private static final String KEY_RESULT = "result";
	private static final String KEY_DATETIME = "datetime";
	
	public DbHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //3rd argument to be passed is CursorFactory instance
    }
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		String CREATE_HISTORY_TABLE = "CREATE TABLE " + TABLE_HISTORYS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_FIRST + " TEXT,"
             + KEY_SIGN + " TEXT," + KEY_SECOND + " TEXT," + KEY_RESULT + " TEXT," + KEY_DATETIME + " TEXT" + ")";
        db.execSQL(CREATE_HISTORY_TABLE);
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_HISTORYS);
		onCreate(db);
	}
	void addHistory(History history){
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		
		values.put(KEY_FIRST, history.getFirst());
		values.put(KEY_SIGN, history.getSign());
		values.put(KEY_SECOND, history.getSecond());
		values.put(KEY_RESULT, history.getResult());
		values.put(KEY_DATETIME, history.getDatetime());
		
		db.insert(TABLE_HISTORYS, null, values);
		db.close();
	}
    public List<History> getAllHistories() {
        List<History> historyList = new ArrayList<History>();
        
        String selectQuery = "SELECT  * FROM " + TABLE_HISTORYS;
 
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
 
        
        if (cursor.moveToFirst()) {
            do {
                History history = new History();
                history.setId(Integer.parseInt(cursor.getString(0)));
                history.setFirst(cursor.getString(1));
                history.setSign(cursor.getString(2));
                history.setSecond(cursor.getString(3));
                history.setResult(cursor.getString(4));
                history.setDatetime(cursor.getString(5));
                
                historyList.add(history);
            } while (cursor.moveToNext());
        }
 
        
        return historyList;
    }

}
