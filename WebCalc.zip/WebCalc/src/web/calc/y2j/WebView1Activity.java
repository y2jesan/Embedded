package web.calc.y2j;

import web.calc.y2j.R;
import web.calc.y2j.webInterface;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;
public class WebView1Activity extends Activity {
    /** Called when the activity is first created. */
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webcal);
        WebView myWeb= (WebView)findViewById(R.id.webView1);
        WebSettings webSet = myWeb.getSettings();
        webSet.setJavaScriptEnabled(true);
        myWeb.addJavascriptInterface(new webInterface(this), "Android");
        
        myWeb.loadUrl("file:///android_asset/index.html");
        //myWeb.loadUrl("www.aiub.edu");
        
        
    }
}