package web.calc.y2j;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class WebCalcActivity extends Activity {
    /** Called when the activity is first created. */
	private Button btnChk;
	
	public boolean isConnection(){
	      ConnectivityManager conState = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		  NetworkInfo activeNetworkInfo = conState.getActiveNetworkInfo();
		  return activeNetworkInfo != null && activeNetworkInfo.isConnected();
		}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        this.btnChk = (Button)findViewById(R.id.buttonChk);
        
        btnChk.setOnClickListener(new OnClickListener(){
        	public void onClick(View view){
        	     if(isConnection()){
        	    	 Toast.makeText(getBaseContext(), "Yes", Toast.LENGTH_LONG).show();
        	    	 Intent i = new Intent(getApplicationContext(), WebView1Activity.class);
         			startActivity(i);
        	     }else{
        	    	 Toast.makeText(getBaseContext(), "No", Toast.LENGTH_LONG).show();
            	     Intent i = new Intent(getApplicationContext(), MyCalculatorActivity.class);
          			startActivity(i);
        	     }
        	   
        	}
        });
    }
}