package profile.manager.y2j;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.IBinder;
import android.widget.Toast;

public class SensorConnection extends Service implements SensorEventListener{
	
	SensorManager sensorManager;
	AudioManager audioManager;
	Sensor lightSensor,accelerometerSensor,proximitySensor;
	boolean noLight=false, faceDown=false;
	public void onCreate(){
		audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        
        lightSensor=sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        
        if (accelerometerSensor != null){
            sensorManager.registerListener(this,accelerometerSensor,SensorManager.SENSOR_DELAY_NORMAL);
            
        }
        else {
        	Toast.makeText(this,"Accelerometer Sensor Not Found",Toast.LENGTH_SHORT).show();
        }
        if (proximitySensor != null){
            sensorManager.registerListener(this,proximitySensor,SensorManager.SENSOR_DELAY_NORMAL);
        }
        else {
        	Toast.makeText(this,"Proximity Sensor Not Found",Toast.LENGTH_SHORT).show();
        }
        if (lightSensor != null){
            sensorManager.registerListener(this,lightSensor,SensorManager.SENSOR_DELAY_NORMAL);
        }
        else {
        	Toast.makeText(this,"Light Sensor Not Found",Toast.LENGTH_SHORT).show();
        }
        
	}

	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub
	}

	public void onSensorChanged(SensorEvent e) {
		// TODO Auto-generated method stub
		
		if (e.sensor.getType() == Sensor.TYPE_LIGHT ) {
			//Camera cam = Camera.open();
            if (e.values[0] < 10) {
                //audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            	noLight=true;     
//            	Parameters p = cam.getParameters();
//            	p.setFlashMode(Parameters.FLASH_MODE_TORCH);
//            	cam.setParameters(p);
//            	cam.startPreview();
            }
            else
            {
                //audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            	noLight=false;
//            	Parameters p = cam.getParameters();
//            	p.setFlashMode(Parameters.FLASH_MODE_OFF);
//            	cam.setParameters(p);
//            	cam.stopPreview();
            }
        }
		
		
		if (e.sensor.getType() == Sensor.TYPE_ACCELEROMETER ) {
            
        }
		if (e.sensor.getType() == Sensor.TYPE_PROXIMITY ) {
			if (e.values[0]== proximitySensor.getMaximumRange()) {
                faceDown=false;
            }
            else{
            	faceDown=true;
            }
        }
		
		if (faceDown){
			audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
		}
		else if (noLight && !faceDown){
			audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
		}
		else if (!noLight && !faceDown){
			audioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
		}
	}

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int onStartCommand(Intent intent,int flags,int Id)
    {
        return START_STICKY;
    }
    public void onDestroy()

    {
        sensorManager.unregisterListener(this);

    }
}
