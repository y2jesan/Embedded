/** Automatically generated file. DO NOT MODIFY */
package profile.manager.y2j;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}