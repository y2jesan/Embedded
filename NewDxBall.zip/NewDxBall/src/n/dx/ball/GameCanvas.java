package n.dx.ball;

import n.dx.ball.Box;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.view.MotionEvent;
import android.view.View;

public class GameCanvas extends View {
	Paint paint;
	boolean start=true;
	boolean running=false;
	boolean isTouch=false;
	int life=3;
	int score=0;
	Box[] Boxs = new Box[50];
	
	int width,height;
	
	//ball var
	float ballX=0,ballY=0, changeX = 8, changeY = -8;
	
	//bar var
	int barTop,barBottom,barLeft,barRight;
	float barMid;
	
	public GameCanvas(Context context) {	
		super(context);
		paint = new Paint();
	}
	public boolean onTouchEvent(MotionEvent event) {
        running =true;
        if(event.getAction()==MotionEvent.ACTION_DOWN){
            isTouch=true;
        }
        if(event.getAction()==MotionEvent.ACTION_UP)
        {
            isTouch=false;
        }
        while (isTouch==true) {
            running = true;
            float touch = event.getX();
            
            barMid = (barLeft + barRight) / 2;
            if (barMid > touch) {
            	barLeft=barLeft-30;
            	barRight=barRight-30;
            }
            if (barMid < touch) {
            	barLeft=barLeft+30;
            	barRight=barRight+30;
            }
            return true;
        }
        return super.onTouchEvent(event);

    }
	protected void onDraw(Canvas canvas)
	{
		if(start)
		{
			isTouch=true;
			start=false;
			ballX=canvas.getWidth() / 2;
			ballY=canvas.getHeight()-40;
			
			barLeft=(canvas.getWidth()/2)-100;
			barTop=canvas.getHeight()-20;
			barRight=(canvas.getWidth()/2)+100;
			barBottom=canvas.getHeight();
			
			
			int initX = 0, initY = 0;
            int b = 0;
            for (int i = 0; i < 50; i++) {
                Boxs[i] = new Box();
            }
            for (int i = 0; i < Boxs.length / 10; i++) {
                for (int j = 0; j < 10; j++) {
                    Boxs[b].bTop = initY;
                    Boxs[b].bBottom = initY + 50;
                    Boxs[b].bLeft = initX;
                    Boxs[b].bRight = initX + canvas.getWidth() / 10;
                    ++b;
                    initX += canvas.getWidth() / 8;
                }
                initX = 0;
                initY += 70;
            }
		}
		if (life == 0) {
            changeX = 0;
            changeY = 0;

            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), paint);

            paint.setColor(Color.RED);
            paint.setTextSize(30);
            canvas.drawText("Game Over", 50 , 100,paint);
            canvas.drawText("Score: "+score, 50, 150, paint);
            
            return;
        }
		
		
		width=canvas.getWidth();
		height=canvas.getHeight();
		
		//calculateNext(canvas);
		
		canvas.drawRGB(255, 255, 255);
		
		paint.setColor(Color.GREEN);
		paint.setStyle(Style.FILL);
		
		//draw Box
		for (int i = 0; i < 50; i++) {
            if (Boxs[i].isHit == false) {
                canvas.drawRect(Boxs[i].bLeft, Boxs[i].bTop, Boxs[i].bRight, Boxs[i].bBottom, paint);
                Boxs[i].setEmpty();
            }
        }
		//draw ball 
		paint.setColor(Color.RED);
		paint.setStyle(Style.FILL);
		
		canvas.drawCircle(ballX,ballY, 20, paint);
		
		//draw bar
		paint.setColor(Color.BLUE);
		paint.setStyle(Style.FILL);
		canvas.drawRect(barLeft,barTop,barRight,barBottom, paint);
		
		 if (running) {

	            calculateNext(canvas);
	            //Box and ball collision
	            for (int i = 0; i < Boxs.length; i++) {
	                if (Boxs[i].isHit == true) continue;
	                
	                if (((ballY - 20) <= Boxs[i].bBottom) && ((ballY + 20) >= Boxs[i].bTop) &&
	                        ((ballX) >= Boxs[i].bLeft) && ((ballX) <= Boxs[i].bRight)) {
	                    Boxs[i].setHit();
	                    changeY = -changeY;
	                    score+=10;
	                    if(score==400)
	                    {
	                        paint.setColor(Color.BLACK);
	                        paint.setStyle(Paint.Style.FILL);
	                        canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), paint);

	                        paint.setColor(Color.RED);
	                        paint.setTextSize(30);
	                        canvas.drawText("Finished", 50, 100, paint);
	                        canvas.drawText("Score: "+score, 50, 150, paint);
	                        return;
	                    }

	                }
	            }
	            //Bar and ball collision
	            if (((ballY + 20 ) >= barTop) && ((ballY - 20 + 20) <= barBottom) && ((ballX) >= barLeft) && ((ballX) <= barRight)) {
	                changeY = -changeY;
	            }
	        }
		
		invalidate();
	}
	private void calculateNext(Canvas canvas) {
		// TODO Auto-generated method stub
		if(ballX-20<=0){
            changeX = Math.abs(changeX);
        }
        else if(ballX+20>=canvas.getWidth()){
            changeX = -changeX;
        }
        else if(ballY<=0){
            changeY = Math.abs(changeY);
        }
        else if(ballY>=canvas.getHeight()){
            --life;
            running = false;
            
            ballX = canvas.getWidth()/2;
            ballY = canvas.getHeight() - 80;
            changeX = 8;
            changeY = -8;
        }
		
        ballX += changeX;
        ballY += changeY;
	}
}
