package n.dx.ball;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Box {
	public int bTop,bBottom,bLeft,bRight;
    public boolean isHit;
    public int index;
    boolean isEmpty=false;
    //Paint paint;
    Paint paint=new Paint();
    
    
    public  Box()
    {
        bLeft = 0;
        bTop = 0;
        bRight = 0;
        bBottom = 0;
        
        isHit = false;
    }
    public void drawBox(Canvas canvas, float Left, float Top, float Right, float Bottom)
    {
    		paint.setColor(Color.BLUE);
    		paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(Left,Top,Right,Bottom,paint);
    }
    public void setHit()
    {
        this.isHit=true;
    }
    public boolean getHIt()
    {
        return isHit;
    }
    public void setEmpty()
    {
        this.isEmpty=true;
    }

}
