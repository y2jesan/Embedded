/** Automatically generated file. DO NOT MODIFY */
package n.dx.ball;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}